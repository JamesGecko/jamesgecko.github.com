theme:rain
==========
For many year evil green square empire may oppressed the lowly yellow square. Now times have come. Take fight and win! Use arrow keys to defeat menace. Smash yellow invincible ship into fragile green hull! Bonus score buy frequent collision! Beware; the red box fire evil rejuvenation. Survive impossible odds in wet rain from sky. Commander... the ship is yours and win.

Use the arrow keys to move in-game. Click on the green square at the title to start.

Graphical design stolen from Cactus ... http://cactusquid.com/
Music by Malcos ... http://ocremix.org/remix/OCR00480/

This game was downloaded from http://jamesgecko.com/2010/04/themerain/